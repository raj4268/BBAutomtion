package main_driver;



//import TestCases.Designtool_backgroundTemplateValidation;
import TestCases.Test_cases;
import TestCases.Testfile;
//import TestCases.Testfile;
import html_Reportmethods.Reporter;

public class Main extends Reporter{

	
	
	
	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
	System.out.println("hii");
//	//-- Get data from Excel Run Manager
//	setExcelFile(Path_TestData + File_TestData, "Input");
//	String getexcelurl = getCellData(i, 0);
	
	
	initialize();
	Test_cases.launchURL("https://www.bannerbuzz.com/customer/account/login");
	//Test_cases.Zeropricefunctionality();
//	Designtool_backgroundTemplateValidation.designTool_Template();
	Testfile.test();
	
	writeResults();

	
	}

}