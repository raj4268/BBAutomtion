package TestCases;

import javax.swing.JOptionPane;

import org.openqa.selenium.support.ui.WebDriverWait;

import ExcelUitil.Excelmethods;
import Reusable_methods.Reusable;

public class Testfile extends Reusable {

	
public static void test()
{
	JOptionPane.showConfirmDialog(null, null);
	
	WebDriverWait wait = new WebDriverWait(driver, 170);
	JOptionPane.showConfirmDialog(null, null);
	
}
	
	
}
