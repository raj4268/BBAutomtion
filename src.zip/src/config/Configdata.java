package config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Configdata {

	public static WebDriver driver = null;
    
	public static final String Path_TestData = System.getProperty("user.dir")+"\\src\\TestData\\";
	public static final String File_TestData = "Designtool_BackgroundTemplate.xlsx";
	public static final String resultPlaceholder = "<!-- INSERT_RESULTS -->";
	public  static final String templatePath = System.getProperty("user.dir")+"\\src\\Screenshots"+"\\report_template.html";
	
//	Designtool_BackgroundTemplate
//	Xmltest
}
