package Reusable_methods;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ExcelUitil.Excelmethods;
import TestCases.Test_cases;

import config.Configdata;
import html_Reportmethods.Reporter;

public class Reusable extends Excelmethods{
	
	
	
	public static WebDriverWait wait = new WebDriverWait(driver, 40);
	

	
	
	public static void waitForLoaderToDisMiss2(WebDriver driver) {
		try {
			new WebDriverWait(driver, 100).until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("(//img[@alt='Loader'])[1]"))));
			}catch (Exception e) {
				System.out.println("Loader does not exist");
			}
		}
	public static void waitForLoaderToDisMiss(WebDriver driver) {
		try {
			new WebDriverWait(driver, 150);
			wait.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath("//*[@src='/static/images/store/3/loader/Loader-GIF-Animation.gif'] | //*[@src='/static/images/store/1/loader/Loader-GIF-Animation.gif']"), ""));
			
			
			
			}catch (Exception e) {
				System.out.println("Loader does not exist");
			}
	}
	public static void clickjavascriptelement(WebDriver driver, WebElement element){

		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);

		}
	public static WebDriver getdriver(String Browser)
	{
		
//		    System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Desktop\\chromedriver.exe");
//			  
//		    driver = new ChromeDriver();
//		    driver.manage().window().maximize();
//		    System.out.println("**Chrome driver initiated1**");
//		return driver;
		switch(Browser) {
        case "chrome" :
           System.out.println("Chrome driver launched"); 
          // Reporter.Reportlog("Done", "Chrome driver launched");
   		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Desktop\\Chromdrivr\\chromedriver.exe\\");
   		
   	    driver = new ChromeDriver();
   	    
   	   // HtmlUnitDriver driver = new HtmlUnitDriver();
   		driver.manage().window().maximize();
   		return driver;	
        case "firefox" :
           System.out.println("Firefox driver launched");
    //      Reporter.Reportlog("Done", "Firefox driver launched");
       	System.setProperty("webdriver.gecko.driver", "C:\\Users\\hp\\Desktop\\gecko\\geckodriver.exe");
		
		  driver = new FirefoxDriver();
		    
		   // HtmlUnitDriver driver = new HtmlUnitDriver();
			driver.manage().window().maximize();
          return driver;
           default :
           System.out.println("No driver launched");
		
		}
		return null;
		}

	
	}



